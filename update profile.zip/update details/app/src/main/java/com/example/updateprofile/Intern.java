package com.example.updateprofile;

import java.io.Serializable;

public class Intern implements Serializable {
    public String RegNo;
    public String Name;
    public String Gender;
    public String StudentCategory;
    public String College;
    public String City;
    public String Course;
    public String CGPA;



}
